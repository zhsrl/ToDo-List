
Winstep Nexus Dock - Winstep Software Technologies: README file


----
Nexus is compatible with the 32 and 64 bit versions of:

Windows 2000, XP, 2003 Server, Vista, Windows 7, Windows 8.x, Windows 10.

----

WARNING: This software is free for PERSONAL USE ONLY!

You may NOT use the Product in corporate or commercial environments,
business use is subject to and requires a special license.

For business use please contact Winstep support at support@winstep.net

----


INSTALLATION: 

To install Nexus, please follow these directions:

1) Exit all running Winstep applications.

2) Unpack the files contained in this ZIP to a temporary folder.

3) Run NexusSetup.exe and complete the installation.

4) Have fun!



-----

GETTING HELP:


Besides the User Guide, your best source of help will be the WinStep
public forums at

http://forums.winstep.net

or email Winstep Support at

support@winstep.net


----

Credits/Permissions:


Nexus uses Zip/Unzip -from the Info-ZIP group- to 
export/import themes from zip files. 
There are no extra charges or costs due to the use of
this code, and the original compression sources are freely available from
http://www.cdrom.com/pub/infozip/ or ftp://ftp.cdrom.com/pub/infozip/
on the Internet.

Nexus uses Regions DLL for Windows 9x/NT, 
created by the KPD-Team 1999
Kris & Pieter Philippaerts, http://users.turboline.be/btl10148/ ,
KPD_Team@Hotmail.com

The first set of Weather icons used by Nexus is included with 
permission of Stardock Corporation. These Weather Images are designed
to provide the various weather conditions reported by weather services.
The images are (c) 2003 by Stardock Corporation.  All rights reserved.
http://www.stardock.com.

The second set of Weather icons used by Nexus is included with
permission of Mark Gisis (aka. Teknofrik). All other non-personal use
is prohibited unless permission is given by author.
http://macthemes.net/forum/viewtopic.php?id=16790724...

The Taped dock background is included with permission of Justin Dowell
(aka. JdCerebro). All other non-personal use is prohibited unless
permission is given by author.
Justin Dowell's e-mail: jdcerebro@gmail.com

The SDVZ1-SDVZ5 dock backgrounds are included with permission of
Robbie_Boy and Stephen Welsh (aka.WebGizmos). All other non-personal
use is prohibited unless permission is given by authors.
Robbie_Boy's e-mail: rob_mead@hotmail.com
Stephen Welsh's e-mail: webgizmos@msn.com

The Gloss running indicators are included with permission of Lasse Salling
(aka. PixelPirate). All other non-personal use is prohibited unless
permission is given by author.
Lasse Salling, http://www.pixelpirate.dk, lassesalling@mail-online.dk

The Sample icons are included with permission of Renato C.Veras
(aka. Treetog) and are part of the Next OS Black series of icons. All other
non-personal use is prohibited unless permission is given by author.
Renato C.Veras, http://www.treetog.com , contact@treetog.com

The Heal, Fire, Magic, Flare, Wind, Water, Teleport, Burn and Fireworks
mouseover animations are copyright Mr.Bubbles 
(http://mrbubblewand.wordpress.com/) and are included in strict accordance
to the Terms of Use guidelines in Mr.Bubbles blog.

Dock backgrounds in the Zippy_20 folder are included with permission of
Paul Lacea (aka. Zippy_20). All other non-personal use is prohibited unless
permission is given by author.
Paul Lacea, http://atractt.webs.com/, zyppy_20@yahoo.com.au

Wanda fish bitmap is copyright DavidWu 
(http://www.codeproject.com/Articles/29184/A-lovely-goldfish-desktop-pet-using-alpha-PNG-and)
and is released under the Code Project Open License (CPOL). 

-----

Copyright (c) 1999-2019 Jorge M.R.Coelho
Winstep Software Technologies

All rights reserved.

E-mail: support@winstep.net
website: http://www.winstep.net
